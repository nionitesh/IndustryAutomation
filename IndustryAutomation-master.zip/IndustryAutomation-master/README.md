# IndustryAutomation
RMC project by CS
